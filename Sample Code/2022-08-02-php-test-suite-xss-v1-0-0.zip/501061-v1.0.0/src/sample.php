<!--
# Sample information

Patterns:
- Source: _GET ==> Filters:[]
- Sanitization: nosanitization ==> Filters:[]
- Filters complete: Filters:[]
- Dataflow: environment_var
- Context: xss_plain
- Sink: echo_func

State:
- State: Bad
- Exploitable: Yes


# Exploit description

1. Create script tag with <script>
-->
<?php
# Init

# Sample
$tainted = $_GET;
$tainted = $tainted["t"];
$sanitized = $tainted;
putenv(("IMPORTANT_VARIABLE=" . $sanitized));
$dataflow = getenv("IMPORTANT_VARIABLE");
$context = ("Hello" . $dataflow);
echo($context);

?>